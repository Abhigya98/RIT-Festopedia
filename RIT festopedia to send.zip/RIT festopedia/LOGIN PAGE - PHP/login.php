<?php

 echo 'Thanks for submitting the form.<br/>';
 echo 'Following are your details:<br> Firstname:$name<br> Lastname=$lastname<br> 
       USN:$usn<br> Email:$email<br>'
 ?>
